<?php
/**

 */

namespace VERVOERPLUGIN\Inc\Abstracts;


if ( ! function_exists( 'add_action' ) ) {
	exit;
}

abstract class Metabox {


}